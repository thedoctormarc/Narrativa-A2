WASD = move
Q,E = dodge
Left Mouse = attack